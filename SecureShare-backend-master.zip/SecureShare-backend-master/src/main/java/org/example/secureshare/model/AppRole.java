package org.example.secureshare.model;

public enum AppRole {
    ROLE_USER,
}
